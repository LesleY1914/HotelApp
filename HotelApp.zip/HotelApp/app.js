const readline = require('readline');
const colors = require('colors');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});


const hotel = {
  habitaciones: [],
  reservas: [],
};


function main() {
  console.log('======================================================================'.yellow);  
  console.log('         Bienvenido a la aplicación de administración de hotel.'.blue);
  console.log('======================================================================'.yellow);  

  rl.question('Seleccione una opción:\n1. Agregar habitación\n2. Ver habitaciones\n3. Hacer una reserva\n4. Ver reservas\n5. Salir\n', (opcion) => {
    switch (opcion) {
      case '1':
        agregarHabitacion();
        break;
      case '2':
        verHabitaciones();
        main();
        break;
      case '3':
        hacerReserva();
        break;
      case '4':
        verReservas();
        main();
        break;
      case '5':
        console.log('Gracias por usar la aplicación de administración de hotel.');
        rl.close();
        break;
      default:
        console.log('Opción no válida. Por favor, seleccione una opción válida.');
        main();
    }
  });
}


function agregarHabitacion() {
  rl.question('Número de habitación: ', (numero) => {
    rl.question('Tipo de habitación (Individual/Doble/Suite): ', (tipo) => {
      rl.question('Precio por noche: ', (precio) => {
        const habitacion = { numero, tipo, precio };
        hotel.habitaciones.push(habitacion);
        console.log('Habitación agregada con éxito.'.green);
        main();
      });
    });
  });
}


function verHabitaciones() {
  console.log('Habitaciones disponibles:');
  hotel.habitaciones.forEach((habitacion) => {
    console.log(`Número: ${habitacion.numero}, Tipo: ${habitacion.tipo}, Precio: $${habitacion.precio}`);
  });
}


function hacerReserva() {
  verHabitaciones();

  rl.question('Ingrese el número de la habitación para la reserva: ', (numeroHabitacion) => {
    const habitacion = hotel.habitaciones.find((h) => h.numero === numeroHabitacion);

    if (!habitacion) {
      console.log('La habitación especificada no existe.'.red);
      main();
      return;
    }

    rl.question('Nombre del cliente: ', (nombre) => {
      rl.question('Fecha de check-in (dd/mm/yyyy): ', (checkIn) => {
        rl.question('Fecha de check-out (dd/mm/yyyy): ', (checkOut) => {
          const reserva = {
            numeroHabitacion,
            nombre,
            checkIn,
            checkOut,
          };

          hotel.reservas.push(reserva);
          console.log('Reserva realizada con éxito.'.green);
          main();
        });
      });
    });
  });
}


function verReservas() {
  console.log('Reservas existentes:');
  hotel.reservas.forEach((reserva) => {
    console.log(`Número de habitación: ${reserva.numeroHabitacion}, Cliente: ${reserva.nombre}, Check-In: ${reserva.checkIn}, Check-Out: ${reserva.checkOut}`);
  });
}


main();
